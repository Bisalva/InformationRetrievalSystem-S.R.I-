var searchData=
[
  ['next_0',['next',['../structAdjListNode.html#ad07931f1bcb5ab15b9baf380a118242c',1,'AdjListNode::next'],['../structInLinkNode.html#a6b6adf7b6901a8a6292daefa8119576f',1,'InLinkNode::next']]],
  ['node_1',['node',['../structNode.html',1,'Node'],['../node__management_8h.html#a3b09f37e675bcd48a01bf22155996872',1,'Node:&#160;node_management.h']]],
  ['node_5fid_2',['node_id',['../structInLinkNode.html#a0da4a5c3597363ef718eda11505302f8',1,'InLinkNode']]],
  ['node_5fmanagement_2ec_3',['node_management.c',['../node__management_8c.html',1,'']]],
  ['node_5fmanagement_2eh_4',['node_management.h',['../node__management_8h.html',1,'']]],
  ['nodes_2ec_5',['nodes.c',['../nodes_8c.html',1,'']]],
  ['nodes_2eh_6',['nodes.h',['../nodes_8h.html',1,'']]],
  ['nodo_7',['nodo',['../structNodo.html',1,'Nodo'],['../nodes_8h.html#ab27a17935caedd91258058c352971251',1,'Nodo:&#160;nodes.h']]],
  ['nombre_5farchivo_8',['nombre_archivo',['../structDocumentoNodo.html#ab3cf5017daa56f2575325785e0e68b48',1,'DocumentoNodo::nombre_archivo'],['../structNodo.html#a9edf5040b18f20ff3ae4ac113ca4e360',1,'Nodo::nombre_archivo']]],
  ['num_5fdocs_9',['num_docs',['../structGraph.html#aca99b1f944b0e630a00c1b199bb2eb46',1,'Graph']]]
];
