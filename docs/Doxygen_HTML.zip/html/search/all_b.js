var searchData=
[
  ['main_0',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;main.c'],['../generador__palabras_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;generador_palabras.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['max_5farchivo_5fmb_2',['MAX_ARCHIVO_MB',['../files_8c.html#a884457fb46bdbccc2faca0847491f519',1,'files.c']]],
  ['max_5fstopwords_3',['MAX_STOPWORDS',['../stopwords_8h.html#a2965e449f699e3422fdb0929dfd44ea8',1,'stopwords.h']]],
  ['max_5fword_5flength_4',['max_word_length',['../stopwords_8h.html#aec7b4994021c554c1761ea31d016b680',1,'MAX_WORD_LENGTH:&#160;stopwords.h'],['../generador__palabras_8c.html#aec7b4994021c554c1761ea31d016b680',1,'MAX_WORD_LENGTH:&#160;generador_palabras.c']]],
  ['max_5fwords_5',['MAX_WORDS',['../generador__palabras_8c.html#acc74efdd29e34bab649ad665326edfe6',1,'generador_palabras.c']]],
  ['memory_2ec_6',['memory.c',['../memory_8c.html',1,'']]],
  ['memory_2eh_7',['memory.h',['../memory_8h.html',1,'']]],
  ['mostrar_5fvista_5fprevia_8',['mostrar_vista_previa',['../docs__management_8h.html#a2bad17c5881aceb297a0f7a2e0e8aef5',1,'mostrar_vista_previa(const char *nombre_archivo, const char *palabra_original):&#160;docs_management.c'],['../docs__management_8c.html#a2bad17c5881aceb297a0f7a2e0e8aef5',1,'mostrar_vista_previa(const char *nombre_archivo, const char *palabra_original):&#160;docs_management.c']]]
];
