var searchData=
[
  ['frecuencia_0',['frecuencia',['../structDocumentoNodo.html#a2a713f89b6e61fb326610743d81e201c',1,'DocumentoNodo']]]
];
