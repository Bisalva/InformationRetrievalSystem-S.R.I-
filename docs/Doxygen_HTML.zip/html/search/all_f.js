var searchData=
[
  ['r_20i_0',['Sistema de Recuperacion de Informacion (S.R.I)',['../md_README.html',1,'']]],
  ['readme_2emd_1',['README.md',['../README_8md.html',1,'']]],
  ['recuperacion_20de_20informacion_20s_20r_20i_2',['Sistema de Recuperacion de Informacion (S.R.I)',['../md_README.html',1,'']]]
];
