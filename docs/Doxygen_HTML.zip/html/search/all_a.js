var searchData=
[
  ['leer_5farchivo_0',['leer_archivo',['../files_8h.html#a03ab63700285c51d1c14d338f43c53ab',1,'leer_archivo(const char *archivo):&#160;files.c'],['../files_8c.html#a03ab63700285c51d1c14d338f43c53ab',1,'leer_archivo(const char *archivo):&#160;files.c']]],
  ['leer_5fpalabras_1',['leer_palabras',['../generador__palabras_8c.html#a7d55f69a9f5c285a4c2dfd293fe55198',1,'generador_palabras.c']]],
  ['liberar_5findice_2',['liberar_indice',['../index__management_8h.html#af1dcf24c9e549b0c934b6521cd8b486b',1,'liberar_indice(IndiceInvertido *indice):&#160;index_management.c'],['../index__management_8c.html#af1dcf24c9e549b0c934b6521cd8b486b',1,'liberar_indice(IndiceInvertido *indice):&#160;index_management.c']]],
  ['liberar_5fmemoria_3',['liberar_memoria',['../memory_8h.html#a9c7b99ad7786418618b330969d1bfb11',1,'liberar_memoria(Nodo *inicio):&#160;memory.c'],['../memory_8c.html#a9c7b99ad7786418618b330969d1bfb11',1,'liberar_memoria(Nodo *inicio):&#160;memory.c']]],
  ['limpiar_5fpalabra_4',['limpiar_palabra',['../word__processing_8h.html#a17df67a2d677b43dc8f197bd0979880a',1,'limpiar_palabra(char *palabra):&#160;word_processing.c'],['../word__processing_8c.html#a17df67a2d677b43dc8f197bd0979880a',1,'limpiar_palabra(char *palabra):&#160;word_processing.c']]]
];
