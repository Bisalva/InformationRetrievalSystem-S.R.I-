var searchData=
[
  ['generador_5fpalabras_2ec_0',['generador_palabras.c',['../generador__palabras_8c.html',1,'']]],
  ['graph_5flinks_2ec_1',['graph_links.c',['../graph__links_8c.html',1,'']]],
  ['graph_5flinks_2eh_2',['graph_links.h',['../graph__links_8h.html',1,'']]],
  ['graph_5fmanagement_2ec_3',['graph_management.c',['../graph__management_8c.html',1,'']]],
  ['graph_5fmanagement_2eh_4',['graph_management.h',['../graph__management_8h.html',1,'']]]
];
