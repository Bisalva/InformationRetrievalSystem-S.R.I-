var searchData=
[
  ['docs_5fmanagement_2ec_0',['docs_management.c',['../docs__management_8c.html',1,'']]],
  ['docs_5fmanagement_2eh_1',['docs_management.h',['../docs__management_8h.html',1,'']]]
];
