var searchData=
[
  ['head_0',['head',['../structAdjList.html#aa7b5d49cc4416d62c88854c9b38102a6',1,'AdjList']]]
];
