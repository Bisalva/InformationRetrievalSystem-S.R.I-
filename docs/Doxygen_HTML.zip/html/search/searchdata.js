var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstvw",
  1: "adginp",
  2: "adfghimnprsw",
  3: "abcefghilmsv",
  4: "acdfhiknopst",
  5: "adginp",
  6: "dimt",
  7: "dirs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "typedefs",
  6: "defines",
  7: "Páginas"
};

