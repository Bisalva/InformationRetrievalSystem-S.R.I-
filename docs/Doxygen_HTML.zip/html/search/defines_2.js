var searchData=
[
  ['max_5farchivo_5fmb_0',['MAX_ARCHIVO_MB',['../files_8c.html#a884457fb46bdbccc2faca0847491f519',1,'files.c']]],
  ['max_5fstopwords_1',['MAX_STOPWORDS',['../stopwords_8h.html#a2965e449f699e3422fdb0929dfd44ea8',1,'stopwords.h']]],
  ['max_5fword_5flength_2',['max_word_length',['../stopwords_8h.html#aec7b4994021c554c1761ea31d016b680',1,'MAX_WORD_LENGTH:&#160;stopwords.h'],['../generador__palabras_8c.html#aec7b4994021c554c1761ea31d016b680',1,'MAX_WORD_LENGTH:&#160;generador_palabras.c']]],
  ['max_5fwords_3',['MAX_WORDS',['../generador__palabras_8c.html#acc74efdd29e34bab649ad665326edfe6',1,'generador_palabras.c']]]
];
