var searchData=
[
  ['damping_5ffactor_0',['DAMPING_FACTOR',['../main_8c.html#af7f4fb608f9020e4aa410551e72ac981',1,'main.c']]],
  ['de_20recuperacion_20de_20informacion_20s_20r_20i_1',['Sistema de Recuperacion de Informacion (S.R.I)',['../md_README.html',1,'']]],
  ['dest_2',['dest',['../structAdjListNode.html#a5e3a8cdea9900b927f140f21685d35c0',1,'AdjListNode']]],
  ['docs_5fmanagement_2ec_3',['docs_management.c',['../docs__management_8c.html',1,'']]],
  ['docs_5fmanagement_2eh_4',['docs_management.h',['../docs__management_8h.html',1,'']]],
  ['document_5fid_5',['document_id',['../structAdjList.html#a0a6622fe991f2bd6330b37e03b8f5238',1,'AdjList']]],
  ['documentonodo_6',['documentonodo',['../structDocumentoNodo.html',1,'DocumentoNodo'],['../indice__invertido_8h.html#a285f610831cf3368ed13e658c93f5d12',1,'DocumentoNodo:&#160;indice_invertido.h']]],
  ['documentos_7',['documentos',['../structPalabraNodo.html#aa3fb11dc7de7f20bc85a6471533d64c9',1,'PalabraNodo']]]
];
