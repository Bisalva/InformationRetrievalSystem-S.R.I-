var searchData=
[
  ['s_20r_20i_0',['Sistema de Recuperacion de Informacion (S.R.I)',['../md_README.html',1,'']]],
  ['set_5fkeyword_5frelevance_1',['set_keyword_relevance',['../pagerank_8h.html#add1d58b03f924cbdf79f9e4b93a935e8',1,'set_keyword_relevance(Node *nodes[], int node_count, const char *keywords[], int keyword_count, const char *documents[]):&#160;pagerank.c'],['../pagerank_8c.html#add1d58b03f924cbdf79f9e4b93a935e8',1,'set_keyword_relevance(Node *nodes[], int node_count, const char *keywords[], int keyword_count, const char *documents[]):&#160;pagerank.c']]],
  ['siguiente_2',['siguiente',['../structDocumentoNodo.html#a0e798a2ea4db724db7b9caba14cf7790',1,'DocumentoNodo::siguiente'],['../structPalabraNodo.html#afda7ce56f07dcde3366c21721a7f9e1e',1,'PalabraNodo::siguiente'],['../structNodo.html#af5be718c41097729f06b87fbcebf8f84',1,'Nodo::siguiente']]],
  ['sistema_20de_20recuperacion_20de_20informacion_20s_20r_20i_3',['Sistema de Recuperacion de Informacion (S.R.I)',['../md_README.html',1,'']]],
  ['stopwords_2ec_4',['stopwords.c',['../stopwords_8c.html',1,'']]],
  ['stopwords_2eh_5',['stopwords.h',['../stopwords_8h.html',1,'']]]
];
