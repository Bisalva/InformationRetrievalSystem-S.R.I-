var searchData=
[
  ['node_0',['Node',['../node__management_8h.html#a3b09f37e675bcd48a01bf22155996872',1,'node_management.h']]],
  ['nodo_1',['Nodo',['../nodes_8h.html#ab27a17935caedd91258058c352971251',1,'nodes.h']]]
];
