var searchData=
[
  ['i_0',['Sistema de Recuperacion de Informacion (S.R.I)',['../md_README.html',1,'']]],
  ['in_5flinks_1',['in_links',['../structNode.html#a569d084f1269556809f8b38c9d7e50c2',1,'Node']]],
  ['index_5fmanagement_2ec_2',['index_management.c',['../index__management_8c.html',1,'']]],
  ['index_5fmanagement_2eh_3',['index_management.h',['../index__management_8h.html',1,'']]],
  ['index_5foperations_2ec_4',['index_operations.c',['../index__operations_8c.html',1,'']]],
  ['index_5foperations_2eh_5',['index_operations.h',['../index__operations_8h.html',1,'']]],
  ['indice_5finvertido_2eh_6',['indice_invertido.h',['../indice__invertido_8h.html',1,'']]],
  ['indiceinvertido_7',['IndiceInvertido',['../structIndiceInvertido.html',1,'']]],
  ['informacion_20s_20r_20i_8',['Sistema de Recuperacion de Informacion (S.R.I)',['../md_README.html',1,'']]],
  ['inicializar_5findice_9',['inicializar_indice',['../index__management_8h.html#ae69d5430d979478f327cc7b692b9d59e',1,'inicializar_indice(IndiceInvertido *indice):&#160;index_management.c'],['../index__management_8c.html#ae69d5430d979478f327cc7b692b9d59e',1,'inicializar_indice(IndiceInvertido *indice):&#160;index_management.c']]],
  ['inlinknode_10',['inlinknode',['../structInLinkNode.html',1,'InLinkNode'],['../node__management_8h.html#ad7f50f70a285ec491925ef5ca839d54c',1,'InLinkNode:&#160;node_management.h']]],
  ['iterations_11',['ITERATIONS',['../main_8c.html#aa9cc087d076e4fa101f8794a947bd01a',1,'main.c']]]
];
