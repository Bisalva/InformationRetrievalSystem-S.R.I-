var searchData=
[
  ['index_5fmanagement_2ec_0',['index_management.c',['../index__management_8c.html',1,'']]],
  ['index_5fmanagement_2eh_1',['index_management.h',['../index__management_8h.html',1,'']]],
  ['index_5foperations_2ec_2',['index_operations.c',['../index__operations_8c.html',1,'']]],
  ['index_5foperations_2eh_3',['index_operations.h',['../index__operations_8h.html',1,'']]],
  ['indice_5finvertido_2eh_4',['indice_invertido.h',['../indice__invertido_8h.html',1,'']]]
];
