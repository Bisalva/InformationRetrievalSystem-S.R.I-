var searchData=
[
  ['contenido_0',['contenido',['../structNodo.html#a22041ab6903b0047eca35092dda26dc9',1,'Nodo']]]
];
