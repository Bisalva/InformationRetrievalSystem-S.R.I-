var searchData=
[
  ['verificar_5fextension_5farchivo_0',['verificar_extension_archivo',['../files_8h.html#afebd091512453faba14f09398bad4986',1,'verificar_extension_archivo(const char *nombre_archivo):&#160;files.c'],['../files_8c.html#afebd091512453faba14f09398bad4986',1,'verificar_extension_archivo(const char *nombre_archivo):&#160;files.c']]]
];
