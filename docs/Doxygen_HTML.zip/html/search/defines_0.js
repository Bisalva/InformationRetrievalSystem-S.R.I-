var searchData=
[
  ['damping_5ffactor_0',['DAMPING_FACTOR',['../main_8c.html#af7f4fb608f9020e4aa410551e72ac981',1,'main.c']]]
];
