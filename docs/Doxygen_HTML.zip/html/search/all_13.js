var searchData=
[
  ['word_5fprocessing_2ec_0',['word_processing.c',['../word__processing_8c.html',1,'']]],
  ['word_5fprocessing_2eh_1',['word_processing.h',['../word__processing_8h.html',1,'']]]
];
