var searchData=
[
  ['de_20recuperacion_20de_20informacion_20s_20r_20i_0',['Sistema de Recuperacion de Informacion (S.R.I)',['../md_README.html',1,'']]]
];
