var searchData=
[
  ['inicializar_5findice_0',['inicializar_indice',['../index__management_8h.html#ae69d5430d979478f327cc7b692b9d59e',1,'inicializar_indice(IndiceInvertido *indice):&#160;index_management.c'],['../index__management_8c.html#ae69d5430d979478f327cc7b692b9d59e',1,'inicializar_indice(IndiceInvertido *indice):&#160;index_management.c']]]
];
