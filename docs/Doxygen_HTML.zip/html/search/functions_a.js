var searchData=
[
  ['set_5fkeyword_5frelevance_0',['set_keyword_relevance',['../pagerank_8h.html#add1d58b03f924cbdf79f9e4b93a935e8',1,'set_keyword_relevance(Node *nodes[], int node_count, const char *keywords[], int keyword_count, const char *documents[]):&#160;pagerank.c'],['../pagerank_8c.html#add1d58b03f924cbdf79f9e4b93a935e8',1,'set_keyword_relevance(Node *nodes[], int node_count, const char *keywords[], int keyword_count, const char *documents[]):&#160;pagerank.c']]]
];
