var searchData=
[
  ['palabranodo_0',['PalabraNodo',['../indice__invertido_8h.html#a243550962a6bebebd53e7e612145695d',1,'indice_invertido.h']]]
];
