var searchData=
[
  ['pagerank_0',['pagerank',['../structNode.html#ad0721a830b222a33f2517c4b35449711',1,'Node']]],
  ['palabra_1',['palabra',['../structPalabraNodo.html#a0ff4ac76ecc66f138350d58b6a12086c',1,'PalabraNodo']]]
];
