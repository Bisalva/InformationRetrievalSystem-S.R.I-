var searchData=
[
  ['next_0',['next',['../structAdjListNode.html#ad07931f1bcb5ab15b9baf380a118242c',1,'AdjListNode::next'],['../structInLinkNode.html#a6b6adf7b6901a8a6292daefa8119576f',1,'InLinkNode::next']]],
  ['node_5fid_1',['node_id',['../structInLinkNode.html#a0da4a5c3597363ef718eda11505302f8',1,'InLinkNode']]],
  ['nombre_5farchivo_2',['nombre_archivo',['../structDocumentoNodo.html#ab3cf5017daa56f2575325785e0e68b48',1,'DocumentoNodo::nombre_archivo'],['../structNodo.html#a9edf5040b18f20ff3ae4ac113ca4e360',1,'Nodo::nombre_archivo']]],
  ['num_5fdocs_3',['num_docs',['../structGraph.html#aca99b1f944b0e630a00c1b199bb2eb46',1,'Graph']]]
];
