var searchData=
[
  ['generar_5fdocumento_0',['generar_documento',['../generador__palabras_8c.html#a73ce871a5bafeede51f2a76b09b669ec',1,'generador_palabras.c']]]
];
