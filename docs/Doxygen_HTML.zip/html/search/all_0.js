var searchData=
[
  ['add_5finlink_0',['add_inlink',['../node__management_8h.html#a6b5da3f01fbff49e9205bc04f44c6da1',1,'add_inlink(Node *node, int source_id):&#160;node_management.c'],['../node__management_8c.html#a6b5da3f01fbff49e9205bc04f44c6da1',1,'add_inlink(Node *node, int source_id):&#160;node_management.c']]],
  ['add_5flink_1',['add_link',['../graph__links_8h.html#a6621b5d485965b636b9c3ccab424bc92',1,'add_link(Graph *graph, int src, int dest):&#160;graph_links.c'],['../graph__links_8c.html#a6621b5d485965b636b9c3ccab424bc92',1,'add_link(Graph *graph, int src, int dest):&#160;graph_links.c']]],
  ['adj_5flist_2eh_2',['adj_list.h',['../adj__list_8h.html',1,'']]],
  ['adjlist_3',['adjlist',['../structAdjList.html',1,'AdjList'],['../adj__list_8h.html#a0d1fc823c2630b2f17aa3a3413ba19d2',1,'AdjList:&#160;adj_list.h']]],
  ['adjlistnode_4',['adjlistnode',['../structAdjListNode.html',1,'AdjListNode'],['../adj__list_8h.html#a2f9c302cc9964867480c60147ac51cd6',1,'AdjListNode:&#160;adj_list.h']]],
  ['agregar_5fdocumento_5',['agregar_documento',['../docs__management_8h.html#abf4b480a25e6cbe60814b375c72506f6',1,'agregar_documento(PalabraNodo *nodo_palabra, const char *nombre_archivo):&#160;docs_management.c'],['../docs__management_8c.html#abf4b480a25e6cbe60814b375c72506f6',1,'agregar_documento(PalabraNodo *nodo_palabra, const char *nombre_archivo):&#160;docs_management.c']]],
  ['agregar_5fnodo_6',['agregar_nodo',['../nodes_8h.html#ad4794da1eb876dd827aa7b912e716fc1',1,'agregar_nodo(Nodo *inicio, const char *nombre_archivo, const char *contenido):&#160;nodes.c'],['../nodes_8c.html#ad4794da1eb876dd827aa7b912e716fc1',1,'agregar_nodo(Nodo *inicio, const char *nombre_archivo, const char *contenido):&#160;nodes.c']]],
  ['agregar_5fpalabra_7',['agregar_palabra',['../index__operations_8h.html#a678bcc4bca58300820a147c38c590519',1,'agregar_palabra(IndiceInvertido *indice, const char *palabra_original, const char *nombre_archivo):&#160;index_operations.c'],['../index__operations_8c.html#a678bcc4bca58300820a147c38c590519',1,'agregar_palabra(IndiceInvertido *indice, const char *palabra_original, const char *nombre_archivo):&#160;index_operations.c']]],
  ['array_8',['array',['../structGraph.html#a5ce846d9f06cd420001634870adee779',1,'Graph']]]
];
