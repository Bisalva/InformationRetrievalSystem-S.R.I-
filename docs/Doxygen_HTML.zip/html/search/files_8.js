var searchData=
[
  ['pagerank_2ec_0',['pagerank.c',['../pagerank_8c.html',1,'']]],
  ['pagerank_2eh_1',['pagerank.h',['../pagerank_8h.html',1,'']]]
];
