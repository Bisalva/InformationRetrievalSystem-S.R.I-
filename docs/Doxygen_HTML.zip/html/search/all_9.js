var searchData=
[
  ['keyword_5frelevance_0',['keyword_relevance',['../structNode.html#a0e19db5f37eda44e3b7482abfbac7a46',1,'Node']]]
];
