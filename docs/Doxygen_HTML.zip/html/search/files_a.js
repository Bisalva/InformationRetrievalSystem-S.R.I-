var searchData=
[
  ['stopwords_2ec_0',['stopwords.c',['../stopwords_8c.html',1,'']]],
  ['stopwords_2eh_1',['stopwords.h',['../stopwords_8h.html',1,'']]]
];
