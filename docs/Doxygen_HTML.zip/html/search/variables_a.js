var searchData=
[
  ['siguiente_0',['siguiente',['../structDocumentoNodo.html#a0e798a2ea4db724db7b9caba14cf7790',1,'DocumentoNodo::siguiente'],['../structPalabraNodo.html#afda7ce56f07dcde3366c21721a7f9e1e',1,'PalabraNodo::siguiente'],['../structNodo.html#af5be718c41097729f06b87fbcebf8f84',1,'Nodo::siguiente']]]
];
