var searchData=
[
  ['dest_0',['dest',['../structAdjListNode.html#a5e3a8cdea9900b927f140f21685d35c0',1,'AdjListNode']]],
  ['document_5fid_1',['document_id',['../structAdjList.html#a0a6622fe991f2bd6330b37e03b8f5238',1,'AdjList']]],
  ['documentos_2',['documentos',['../structPalabraNodo.html#aa3fb11dc7de7f20bc85a6471533d64c9',1,'PalabraNodo']]]
];
