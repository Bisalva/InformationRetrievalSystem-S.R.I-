var searchData=
[
  ['documentonodo_0',['DocumentoNodo',['../indice__invertido_8h.html#a285f610831cf3368ed13e658c93f5d12',1,'indice_invertido.h']]]
];
