var searchData=
[
  ['free_5fgraph_0',['free_graph',['../graph__management_8h.html#aae200c11ba4c066ae719ac2fe6b376c3',1,'free_graph(Graph *graph):&#160;graph_management.c'],['../graph__management_8c.html#aae200c11ba4c066ae719ac2fe6b376c3',1,'free_graph(Graph *graph):&#160;graph_management.c']]],
  ['free_5fnodes_1',['free_nodes',['../node__management_8h.html#a9756eee4b507cbda4f6ae1db3fb7e808',1,'free_nodes(Node *nodes[], int node_count):&#160;node_management.c'],['../node__management_8c.html#a9756eee4b507cbda4f6ae1db3fb7e808',1,'free_nodes(Node *nodes[], int node_count):&#160;node_management.c']]]
];
