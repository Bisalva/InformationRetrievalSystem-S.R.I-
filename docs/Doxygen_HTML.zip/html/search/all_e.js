var searchData=
[
  ['pagerank_0',['pagerank',['../structNode.html#ad0721a830b222a33f2517c4b35449711',1,'Node']]],
  ['pagerank_2ec_1',['pagerank.c',['../pagerank_8c.html',1,'']]],
  ['pagerank_2eh_2',['pagerank.h',['../pagerank_8h.html',1,'']]],
  ['palabra_3',['palabra',['../structPalabraNodo.html#a0ff4ac76ecc66f138350d58b6a12086c',1,'PalabraNodo']]],
  ['palabranodo_4',['palabranodo',['../structPalabraNodo.html',1,'PalabraNodo'],['../indice__invertido_8h.html#a243550962a6bebebd53e7e612145695d',1,'PalabraNodo:&#160;indice_invertido.h']]]
];
