var searchData=
[
  ['main_0',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;main.c'],['../generador__palabras_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;generador_palabras.c']]],
  ['mostrar_5fvista_5fprevia_1',['mostrar_vista_previa',['../docs__management_8h.html#a2bad17c5881aceb297a0f7a2e0e8aef5',1,'mostrar_vista_previa(const char *nombre_archivo, const char *palabra_original):&#160;docs_management.c'],['../docs__management_8c.html#a2bad17c5881aceb297a0f7a2e0e8aef5',1,'mostrar_vista_previa(const char *nombre_archivo, const char *palabra_original):&#160;docs_management.c']]]
];
