var searchData=
[
  ['buscar_5fpalabra_0',['buscar_palabra',['../index__operations_8h.html#a4dd5961c5186edad4542934f8b78e49f',1,'buscar_palabra(IndiceInvertido *indice, const char *palabra):&#160;index_operations.c'],['../index__operations_8c.html#af7e0c8cc6257d050f9201a793fae1fd4',1,'buscar_palabra(IndiceInvertido *indice, const char *palabra_original):&#160;index_operations.c']]]
];
