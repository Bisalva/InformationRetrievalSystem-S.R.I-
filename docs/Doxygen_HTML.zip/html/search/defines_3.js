var searchData=
[
  ['tamano_5ftabla_0',['TAMANO_TABLA',['../indice__invertido_8h.html#a0f65e1a0583e587b13b05f49399129ef',1,'indice_invertido.h']]],
  ['total_5fdocs_1',['TOTAL_DOCS',['../main_8c.html#aa84f0d11222509828d6b5ada81924887',1,'main.c']]]
];
