var searchData=
[
  ['es_5fstopword_0',['es_stopword',['../stopwords_8h.html#a33ff094aefb7debef39a23e1c53baa36',1,'es_stopword(const char *palabra, char stopwords[][MAX_WORD_LENGTH], int num_stopwords):&#160;stopwords.c'],['../stopwords_8c.html#a33ff094aefb7debef39a23e1c53baa36',1,'es_stopword(const char *palabra, char stopwords[][MAX_WORD_LENGTH], int num_stopwords):&#160;stopwords.c']]]
];
